package com.example.collegescheduler;

public class ToDoAdapter {
}
